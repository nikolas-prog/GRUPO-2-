const claveCarrito = "kovo-carrito";
const productosCarrito = document.getElementById("productos-carrito");
const carritoVacio = document.getElementById("carrito-vacio");
const cantidadProductos = document.getElementById("cantidad-productos");
const subtotalCarrito = document.getElementById("subtotal-carrito");
const totalCarrito = document.getElementById("total-carrito");

const obtenerCarrito = function () {
    return JSON.parse(localStorage.getItem(claveCarrito)) || [];
};

const guardarCarrito = function (carrito) {
    localStorage.setItem(claveCarrito, JSON.stringify(carrito));
};

const formatoPrecio = function (precio) {
    return `S/${precio.toFixed(2).replace(".", ",")}`;
};

const obtenerImagen = function (imagen) {
    if (!imagen) return "";
    if (/^(https?:|data:|file:)/.test(imagen)) return imagen;
    return new URL(imagen.replace(/^\.\//, ""), new URL("../", window.location.href)).href;
};

const dibujarCarrito = function () {
    const carrito = obtenerCarrito();
    const cantidad = carrito.reduce(function (total, producto) {
        return total + producto.cantidad;
    }, 0);
    const subtotal = carrito.reduce(function (total, producto) {
        return total + producto.precio * producto.cantidad;
    }, 0);

    cantidadProductos.textContent = `${cantidad} ${cantidad === 1 ? "prenda" : "prendas"}`;
    subtotalCarrito.textContent = formatoPrecio(subtotal);
    totalCarrito.textContent = formatoPrecio(subtotal);
    carritoVacio.hidden = carrito.length > 0;
    document.getElementById("vaciar-carrito").hidden = carrito.length === 0;

    productosCarrito.innerHTML = carrito.map(function (producto, indice) {
        return `<article class="producto-carrito">
            <div class="imagen-producto">
                ${producto.imagen ? `<img src="${obtenerImagen(producto.imagen)}" alt="${producto.nombre}">` : ""}
            </div>
            <div class="datos-producto">
                <span class="tipo-producto">KOVO / COLECCION</span>
                <h3>${producto.nombre}</h3>
                <p class="precio-producto">${formatoPrecio(producto.precio)}</p>
                <div class="controles-producto">
                    <button type="button" data-accion="restar" data-indice="${indice}" aria-label="Restar una unidad">−</button>
                    <span>${producto.cantidad}</span>
                    <button type="button" data-accion="sumar" data-indice="${indice}" aria-label="Añadir una unidad">+</button>
                </div>
            </div>
            <button class="eliminar-producto" type="button" data-accion="eliminar" data-indice="${indice}" aria-label="Eliminar ${producto.nombre}">
                <i class="fa-solid fa-xmark" aria-hidden="true"></i>
            </button>
        </article>`;
    }).join("");
};

productosCarrito.addEventListener("click", function (evento) {
    const boton = evento.target.closest("button");
    if (!boton) return;
    const carrito = obtenerCarrito();
    const indice = Number(boton.dataset.indice);
    if (boton.dataset.accion === "sumar") carrito[indice].cantidad += 1;
    if (boton.dataset.accion === "restar") carrito[indice].cantidad -= 1;
    if (boton.dataset.accion === "eliminar") carrito.splice(indice, 1);
    guardarCarrito(carrito.filter(function (producto) { return producto.cantidad > 0; }));
    dibujarCarrito();
});

document.getElementById("vaciar-carrito").addEventListener("click", function () {
    guardarCarrito([]);
    dibujarCarrito();
});

document.getElementById("boton-pagar").addEventListener("click", function () {
    if (obtenerCarrito().length) window.location.href = "../procesamientodepago/pago.html";
});

dibujarCarrito();