const claveCarrito = "kovo-carrito";
const obtenerCarrito = function () {
    return JSON.parse(localStorage.getItem(claveCarrito)) || [];
};
const formatoPrecio = function (precio) {
    return `S/${precio.toFixed(2).replace(".", ",")}`;
};
const carrito = obtenerCarrito();
const subtotal = carrito.reduce(function (total, producto) {
    return total + producto.precio * producto.cantidad;
}, 0);
const productosResumen = document.getElementById("productos-resumen");
const imagenProducto = function (imagen) {
    if (!imagen) return "";
    if (/^(https?:|data:|file:)/.test(imagen)) return imagen;
    return new URL(imagen.replace(/^\.\//, ""), new URL("../", window.location.href)).href;
};

productosResumen.innerHTML = carrito.map(function (producto) {
    return `<div class="producto-resumen">${producto.imagen ? `<img src="${imagenProducto(producto.imagen)}" alt="">` : ""}<div><strong>${producto.nombre}</strong><span>${formatoPrecio(producto.precio)}</span><small>Cantidad: ${producto.cantidad}</small></div></div>`;
}).join("");
document.getElementById("subtotal-resumen").textContent = formatoPrecio(subtotal);
document.getElementById("total-resumen").textContent = formatoPrecio(subtotal);

let pantallaActual = 1;
const pantallas = document.querySelectorAll(".pantalla-formulario");
const pasos = document.querySelectorAll(".paso");
const mostrarPantalla = function (numero) {
    pantallaActual = numero;
    pantallas.forEach(function (pantalla) {
        const activa = Number(pantalla.dataset.pantalla) === numero;
        pantalla.hidden = !activa;
        pantalla.classList.toggle("activa", activa);
    });
    pasos.forEach(function (paso) {
        paso.classList.toggle("activo", Number(paso.dataset.paso) <= numero);
    });
    window.scrollTo({ top: 0, behavior: "smooth" });
};

const validarPantalla = function () {
    const pantalla = document.querySelector(`[data-pantalla="${pantallaActual}"]`);
    const campos = pantalla.querySelectorAll("input[required]");
    for (const campo of campos) {
        if (!campo.value.trim() || !campo.checkValidity()) {
            campo.focus();
            campo.reportValidity();
            return false;
        }
    }
    return true;
};

const tipoDocumento = document.getElementById("tipo-documento");
const numeroDocumento = document.getElementById("numero-documento");
const nombres = document.getElementById("nombre");
const apellidos = document.getElementById("apellido");
const permitirSoloLetras = function (campo) {
    campo.value = campo.value.replace(/[^\p{L}\s]/gu, "");
};

[nombres, apellidos].forEach(function (campo) {
    campo.addEventListener("input", function () {
        permitirSoloLetras(campo);
    });
});

const actualizarValidacionDocumento = function () {
    const esDni = tipoDocumento.value === "dni";
    numeroDocumento.setCustomValidity("");
    numeroDocumento.placeholder = esDni ? "8 dígitos" : "Escribe tu número";
    if (!esDni) return;
    if (!/^\d{8}$/.test(numeroDocumento.value)) {
        numeroDocumento.setCustomValidity("El DNI debe tener exactamente 8 dígitos.");
    }
};

numeroDocumento.addEventListener("input", function () {
    if (tipoDocumento.value === "dni") {
        numeroDocumento.value = numeroDocumento.value.replace(/\D/g, "");
    }
    actualizarValidacionDocumento();
});
tipoDocumento.addEventListener("change", actualizarValidacionDocumento);
actualizarValidacionDocumento();

const telefono = document.getElementById("telefono");
const actualizarValidacionTelefono = function () {
    telefono.setCustomValidity("");
    if (!/^9\d{8}$/.test(telefono.value)) {
        telefono.setCustomValidity("El teléfono debe tener 9 dígitos y comenzar por 9.");
    }
};

telefono.addEventListener("input", function () {
    telefono.value = telefono.value.replace(/\D/g, "");
    actualizarValidacionTelefono();
});
actualizarValidacionTelefono();

const numeroTarjeta = document.getElementById("numero-tarjeta");
const actualizarValidacionTarjeta = function () {
    const digitos = numeroTarjeta.value.replace(/\D/g, "");
    numeroTarjeta.setCustomValidity("");
    if (document.querySelector("input[name='metodo']:checked").value === "tarjeta" && digitos.length !== 16) {
        numeroTarjeta.setCustomValidity("El número de tarjeta debe tener 16 dígitos.");
    }
};

numeroTarjeta.addEventListener("input", function () {
    const digitos = numeroTarjeta.value.replace(/\D/g, "").slice(0, 16);
    numeroTarjeta.value = digitos.replace(/(\d{4})(?=\d)/g, "$1 ");
    actualizarValidacionTarjeta();
});
actualizarValidacionTarjeta();

const vencimiento = document.getElementById("vencimiento");
const actualizarValidacionVencimiento = function () {
    vencimiento.setCustomValidity("");
    if (!/^\d{2}\/\d{2}$/.test(vencimiento.value)) {
        vencimiento.setCustomValidity("Escribe el vencimiento con el formato MM/AA.");
            return;
        }
        const mes = Number(vencimiento.value.slice(0, 2));
        if (mes < 1 || mes > 12) {
            vencimiento.setCustomValidity("El mes de vencimiento debe estar entre 01 y 12.");
    }
};

vencimiento.addEventListener("input", function () {
    const digitos = vencimiento.value.replace(/\D/g, "").slice(0, 4);
    vencimiento.value = digitos.length > 2 ? `${digitos.slice(0, 2)}/${digitos.slice(2)}` : digitos;
    actualizarValidacionVencimiento();
});
actualizarValidacionVencimiento();

const cvv = document.getElementById("cvv");
const actualizarValidacionCvv = function () {
    cvv.setCustomValidity("");
    if (document.querySelector("input[name='metodo']:checked").value === "tarjeta" && !/^\d{3}$/.test(cvv.value)) {
        cvv.setCustomValidity("El CVV debe tener exactamente 3 números.");
    }
};

cvv.addEventListener("input", function () {
    cvv.value = cvv.value.replace(/\D/g, "").slice(0, 3);
    actualizarValidacionCvv();
});
actualizarValidacionCvv();

document.querySelectorAll(".siguiente").forEach(function (boton) {
    boton.addEventListener("click", function () {
        if (!validarPantalla()) return;
        if (pantallaActual === 3) {
            document.getElementById("numero-pedido").textContent = `KOVO-${Date.now().toString().slice(-6)}`;
        }
        mostrarPantalla(Math.min(pantallaActual + 1, 4));
    });
});
document.querySelectorAll(".anterior").forEach(function (boton) {
    boton.addEventListener("click", function () { mostrarPantalla(Math.max(pantallaActual - 1, 1)); });
});
const actualizarEnvio = function () {
    const envioSeleccionado = document.querySelector("input[name='envio']:checked");
    const esDomicilio = envioSeleccionado.value === "domicilio";
    const campoDireccion = document.getElementById("direccion");
    const etiquetaDireccion = document.getElementById("etiqueta-direccion");
    document.querySelector(".domicilio-campo").hidden = false;
    campoDireccion.required = esDomicilio;
    campoDireccion.readOnly = !esDomicilio;
    etiquetaDireccion.textContent = esDomicilio ? "Dirección de entrega" : "Recoger en";
    campoDireccion.value = esDomicilio ? "" : "Tienda KOVO - Av. Alfredo Mendiola 5210";
    campoDireccion.placeholder = esDomicilio ? "Av. o Jr., número y referencia" : "";
    document.getElementById("envio-resumen").textContent = esDomicilio ? "S/7,90" : "Gratis";
};

document.querySelectorAll("input[name='envio']").forEach(function (radio) {
    radio.addEventListener("change", actualizarEnvio);
});
actualizarEnvio();

document.querySelectorAll("input[name='metodo']").forEach(function (radio) {
    radio.addEventListener("change", function () {
        const esTarjeta = document.querySelector("input[name='metodo']:checked").value === "tarjeta";
        document.querySelector(".campos-tarjeta").hidden = !esTarjeta;
        document.querySelectorAll(".campos-tarjeta input").forEach(function (campo) {
            campo.required = esTarjeta;
        });
        actualizarValidacionTarjeta();
        actualizarValidacionCvv();
    });
});

if (!carrito.length) {
    document.querySelector(".formulario-checkout").innerHTML = "<div class=\"sin-productos\"><h2>Tu carrito está vacío</h2><a class=\"boton-principal enlace-boton\" href=\"../index.html\">Volver a la tienda</a></div>";
}