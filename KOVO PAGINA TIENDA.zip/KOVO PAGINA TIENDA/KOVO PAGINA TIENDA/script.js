const abrirMenu = document.getElementById("abrir-menu");
const cerrarMenu = document.getElementById("cerrar-menu");
const menuLateral = document.getElementById("menu-lateral");
const fondoMenu = document.getElementById("fondo-menu");

const cerrarMenuLateral = function () {
    if (menuLateral) menuLateral.classList.remove("activo");
    if (fondoMenu) fondoMenu.classList.remove("activo");
};

if (abrirMenu) abrirMenu.addEventListener("click", function () {
    menuLateral.classList.add("activo");
    fondoMenu.classList.add("activo");
});

if (cerrarMenu) cerrarMenu.addEventListener("click", cerrarMenuLateral);
if (fondoMenu) fondoMenu.addEventListener("click", cerrarMenuLateral);

document.addEventListener("keydown", function (evento) {
    if (evento.key === "Escape") cerrarMenuLateral();
});

const claveCarrito = "kovo-carrito";
const obtenerCarrito = function () {
    return JSON.parse(localStorage.getItem(claveCarrito)) || [];
};
const guardarCarrito = function (carrito) {
    localStorage.setItem(claveCarrito, JSON.stringify(carrito));
};
const formatoPrecio = function (precio) {
    return `S/${precio.toFixed(2).replace(".", ",")}`;
};
const obtenerImagenDeTarjeta = function (tarjeta) {
    const imagen = tarjeta.querySelector(".imagen-producto");
    if (!imagen) return "";
    const fondo = getComputedStyle(imagen).backgroundImage;
    const coincidencia = fondo.match(/url\(["']?(.*?)["']?\)/);
    return coincidencia ? coincidencia[1] : "";
};

const panelCarrito = document.createElement("aside");
panelCarrito.className = "panel-carrito";
panelCarrito.setAttribute("aria-label", "Carrito de compra");
panelCarrito.innerHTML = `<div class="encabezado-carrito"><h2>Tu carrito</h2><button class="cerrar-carrito" aria-label="Cerrar carrito">&times;</button></div><div class="contenido-carrito"></div>`;
document.body.appendChild(panelCarrito);
const contenidoCarrito = panelCarrito.querySelector(".contenido-carrito");

const actualizarContador = function () {
    const cantidad = obtenerCarrito().reduce(function (total, producto) {
        return total + producto.cantidad;
    }, 0);
    document.querySelectorAll(".contador-carrito").forEach(function (contador) {
        contador.textContent = cantidad;
        contador.hidden = cantidad === 0;
    });
};

const renderizarCarrito = function () {
    const carrito = obtenerCarrito();
    let carritoActualizado = false;
    carrito.forEach(function (producto) {
        if (producto.imagen) return;
        const boton = Array.from(document.querySelectorAll(".boton-comprar-inicio"))
            .find(function (elemento) { return elemento.dataset.nombre === producto.nombre; });
        if (!boton) return;
        const imagen = obtenerImagenDeTarjeta(boton.closest(".tarjeta-producto"));
        if (imagen) {
            producto.imagen = imagen;
            carritoActualizado = true;
        }
    });
    if (carritoActualizado) guardarCarrito(carrito);
    if (!carrito.length) {
        contenidoCarrito.innerHTML = "<p class=\"carrito-vacio\">Tu carrito está vacío.</p>";
        actualizarContador();
        return;
    }
    const productos = carrito.map(function (producto, indice) {
        return `<div class="item-carrito"><img src="${producto.imagen}" alt="${producto.nombre}"><div class="datos-item-carrito"><strong>${producto.nombre}</strong><span>${formatoPrecio(producto.precio)} x ${producto.cantidad}</span><div class="controles-carrito"><button data-accion="restar" data-indice="${indice}">-</button><button data-accion="sumar" data-indice="${indice}">+</button><button data-accion="eliminar" data-indice="${indice}">Eliminar</button></div></div></div>`;
    }).join("");
    const total = carrito.reduce(function (suma, producto) {
        return suma + producto.precio * producto.cantidad;
    }, 0);
        contenidoCarrito.innerHTML = `${productos}<div class="total-carrito"><strong>Total</strong><strong>${formatoPrecio(total)}</strong></div><div class="acciones-carrito"><button class="ver-carrito" data-accion="ver-carrito">Ver mi carrito</button></div><button class="vaciar-carrito" data-accion="vaciar">Vaciar carrito</button>`;
    actualizarContador();
};

document.querySelectorAll(".iconos a[aria-label='Carrito de compra']").forEach(function (enlace) {
    const contador = document.createElement("span");
    contador.className = "contador-carrito";
    enlace.appendChild(contador);
    enlace.addEventListener("click", function (evento) {
        evento.preventDefault();
        renderizarCarrito();
        panelCarrito.classList.add("activo");
    });
});

panelCarrito.querySelector(".cerrar-carrito").addEventListener("click", function () {
    panelCarrito.classList.remove("activo");
});

contenidoCarrito.addEventListener("click", function (evento) {
    const boton = evento.target.closest("button");
    if (!boton) return;
    const carrito = obtenerCarrito();
    const indice = Number(boton.dataset.indice);
    if (boton.dataset.accion === "sumar") carrito[indice].cantidad += 1;
    if (boton.dataset.accion === "restar") carrito[indice].cantidad -= 1;
    if (boton.dataset.accion === "eliminar") carrito.splice(indice, 1);
    if (boton.dataset.accion === "vaciar") carrito.length = 0;
    if (boton.dataset.accion === "ver-carrito") {
        const rutaScript = document.querySelector("script[src$='script.js']").src;
        window.location.href = new URL("carritopag/carritopag.html", rutaScript).href;
        return;
    }
    guardarCarrito(carrito.filter(function (producto) { return producto.cantidad > 0; }));
    renderizarCarrito();
});

const añadirProducto = function (datos, boton) {
    const carrito = obtenerCarrito();
    const producto = carrito.find(function (item) { return item.nombre === datos.nombre; });
    if (producto) producto.cantidad += 1;
    else carrito.push({ ...datos, cantidad: 1 });
    guardarCarrito(carrito);
    actualizarContador();
    if (panelCarrito.classList.contains("activo")) renderizarCarrito();
    boton.textContent = "Añadido";
    setTimeout(function () { boton.textContent = "Comprar"; }, 1200);
};

document.querySelectorAll(".producto").forEach(function (tarjeta) {
    const boton = tarjeta.querySelector("button");
    if (!boton) return;
    boton.addEventListener("click", function (evento) {
        evento.preventDefault();
        evento.stopPropagation();
        añadirProducto({
            nombre: tarjeta.querySelector("h3").textContent.trim(),
            precio: Number(tarjeta.querySelector("p").textContent.replace("S/", "").replace(",", ".").trim()),
            imagen: tarjeta.querySelector("img").src
        }, boton);
    });
});

document.querySelectorAll(".boton-comprar-inicio").forEach(function (boton) {
    boton.addEventListener("click", function (evento) {
        evento.preventDefault();
        evento.stopPropagation();
        añadirProducto({
            nombre: boton.dataset.nombre,
            precio: Number(boton.dataset.precio),
            imagen: obtenerImagenDeTarjeta(boton.closest(".tarjeta-producto"))
        }, boton);
    });
});

actualizarContador();